#ifndef _DMX_DEVICES_H
#define _DMX_DEVICES_H

#include "main.h"


void set_par56(uint16_t addr, uint8_t r,uint8_t g, uint8_t b);
void set_par32(uint16_t addr, uint8_t r,uint8_t g, uint8_t b);
void set_par32uv(uint16_t addr, uint8_t uv);
void set_quadphase(uint16_t addr, int8_t rotation,uint8_t r,uint8_t g, uint8_t b);
void set_fog(uint16_t addr, uint8_t state);


#define ADDR_FOG 1 
#define ADDR_LED1 2
#define ADDR_LED2 7
#define ADDR_STROB1 13
#define ADDR_STROB2 19
#define ADDR_SCAN1	25
#define ADDR_SCAN2	35


#endif
