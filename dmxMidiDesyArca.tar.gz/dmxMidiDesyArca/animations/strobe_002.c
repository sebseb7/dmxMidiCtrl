#include "main.h"
#include <stdio.h>

#include "dmx_devices.h"

// ch1 : 1-16 red
// 		 17-33 green
// 		 34-50 blue


// ch2 : 0-9 no rot
//       10-120 clockwise
//       121-134 no
//       135-245 counter
//       246-249 no 
//       250-255 music

uint16_t a;

static uint8_t tick(void) 
{
	a++;
		

	if((a%4) == 2)
	{
		setCh(18+6,255);
	}
	else if(a%4)
	{
		setCh(18,0);
		setCh(18+6,0);
	}
	else
	{
		setCh(18,255);
	}
	return 1;
}

static void init(void)
{
	a=0;
}


static void deinit(void)
{
}



static void constructor(void) CONSTRUCTOR_ATTRIBUTES
void constructor(void) {
	registerAnimation_str(init,tick,deinit, QUADPHASE,30, 3,1);
}


