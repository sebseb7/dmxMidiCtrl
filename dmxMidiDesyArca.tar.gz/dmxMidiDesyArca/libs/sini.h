#ifndef _SINI_H
#define _SINI_H

uint16_t sini(uint16_t x);

#endif
