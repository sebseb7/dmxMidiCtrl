#include "main.h"
#include <stdio.h>
#include "dmx_devices.h"

uint16_t a;

static uint8_t tick(void) 
{
	a++;

	if(a%2)
	{

		set_par56(ADDR_LED1, 0,0,255);
		set_par56(ADDR_LED2, 0,0,255);
	}
	else
	{

		set_par56(ADDR_LED1, 0,0,0);
		set_par56(ADDR_LED2, 0,0,0);
	}


	return 1;
}

static void init(void)
{
	a=0;
}


static void deinit(void)
{
}



static void constructor(void) CONSTRUCTOR_ATTRIBUTES
void constructor(void) {
	registerAnimation(init,tick,deinit, PAR56,30, 3,1);
}


